import React from "react";

const Announcements = () => {
  return <div>Announcements</div>;
};

export default Announcements;
