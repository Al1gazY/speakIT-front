import React from "react";

const Organizations = () => {
  return <div>Organizations</div>;
};

export default Organizations;
