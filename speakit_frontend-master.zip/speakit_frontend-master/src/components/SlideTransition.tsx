import { Slide, SlideProps } from "@mui/material";


export function SlideTransition(props: SlideProps) {
  return <Slide {...props} direction="up" />;
}


