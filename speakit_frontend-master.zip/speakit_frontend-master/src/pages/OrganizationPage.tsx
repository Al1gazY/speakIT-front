import React, { FC } from "react";

const OrganizationPage: FC = () => {
  return <div>OrganizationPage</div>;
};

export default OrganizationPage;
